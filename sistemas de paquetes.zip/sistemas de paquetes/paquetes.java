import java.util.Scanner;

public class paquetes extends envio {
       
    public int Pesocosto = 4000;
    public int volumencosto = 5000;
    Scanner entrada = new Scanner(System.in);
   //*funciones  que piden los datos al usuario para realiza r la respectiva formula*//
    public void calcular_envioEstandar() {
        //peticion de un envio estandar
        System.out.println("-------------------------------");
        System.out.print("dijiste el peso del paquete: ");
        this.peso = entrada.nextDouble();
        System.out.println("-------------------------------");
        System.out.print("dijita el volumen del paquete: ");
        this.volumen = entrada.nextDouble();
        System.out.println("-------------------------------");
        System.out.println("a qui esta la cuenta de su envio: " + calcularCosto1() +"$");
        System.out.println("-------------------------------");

    }

    public void calcular_envioFragil() {
          //peticion de un envio fragil 
        System.out.println("este paquete sera puesto en prioridad FRAGIL");
        System.out.println("-------------------------------");
        System.out.print("dijiste el peso del paquete: ");
        this.peso = entrada.nextDouble();
        System.out.println("-------------------------------");
        System.out.print("dijita el volumen del paquete: ");
        this.volumen = entrada.nextDouble();
        System.out.println("-----------------------------------");
        System.out.println("aqui esta el coste del envio: " + calcularCosto2()+"$");
        System.out.println("-------------------------------");

    }

    public void calcular_envioUrgente() {
          //peticion de un envio urgente
        System.out.println("este envio es urgente y sera puesto en prioridad ALTA!");
        System.out.println("-------------------------------");
        System.out.println("dijiste el peso del paquete ");
        this.peso = entrada.nextDouble();
        System.out.println("-------------------------------");
        System.out.println("dijita el volumen del paquete");
        this.volumen = entrada.nextDouble();
        System.out.println("-------------------------------");
        System.out.println("a qui esta la cuenta de su envio : " + calcularCosto3()+"$");

    }
     //*formulas que *//
    private double calcularCosto1() {
        return getPeso() * Pesocosto + getVolumen() * volumencosto;
        // Calcula el costo multiplicando el peso por el costo por peso (Pesocosto)
        // y sumando el volumen multiplicado por el costo por volumen (volumencosto)
    }

    private double calcularCosto2() {
        return (peso * Pesocosto + volumen * volumencosto) + 200000;
        // Calcula el costo estándar (peso * Pesocosto + volumen * volumencosto)
        // y agrega un recargo adicional de 200000 por envío urgente
    }

    public double calcularCosto3() {
        return (peso * Pesocosto + volumen * volumencosto) + 35000;
        // Calcula el costo estándar (peso * Pesocosto + volumen * volumencosto)
        // y agrega un recargo adicional de 35000 por paquetes frágiles
    }

}
