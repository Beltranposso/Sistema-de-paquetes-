import java.util.Scanner;

public class Recepcion extends paquetes {

    public void Recepcion() {
        Scanner entrada = new Scanner(System.in);
        int opcion;// Variable para almacenar la opción seleccionada por el usuario
        do {
            // Menú principal
            System.out.println("Que tipo de paquete deseas enviar hoy ? ");
            System.out.println("-------------------------------------------");
            System.out.println("1. paquete normal");
            System.out.println("2. paquete frajil");
            System.out.println("3. paquete urgente");
            System.out.println("0. salir");
            System.out.print("Ingresa una opción: ");
            opcion = entrada.nextInt();

            // Evalua la opción seleccionada
            switch (opcion) {
                //llammado ala funcion" calcular_envioEstandar();"
                case 1:
                    calcular_envioEstandar();
                    break;
                    
                case 2:
                //llammado ala funcion" calcular_envioFragil();"
                    calcular_envioFragil();
                    break;
                case 3:
                //llammado ala funcion" calcular_envioUrgente();"
                    calcular_envioUrgente();
                    break;

                default:
                    System.out.println("-------------------------------------------");
                    System.out.println("Gracias por visitarnos!!!");
                    System.out.println("-------------------------------------------");

            }

        } while (opcion != 0);// Repetir hasta que se seleccione la opción 0 (salir)
    }

}
