public class main {

    public static void main(String[] args) {
        Recepcion recepcion1 = new Recepcion();
        //instancia de la clase recepcion
        recepcion1.Recepcion();

    }
}
